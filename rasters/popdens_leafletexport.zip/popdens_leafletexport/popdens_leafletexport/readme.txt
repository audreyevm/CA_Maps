Source: http://sedac.ciesin.columbia.edu/data/set/gpw-v4-population-density-rev10

Citation: 
Center for International Earth Science Information Network - CIESIN - Columbia University. 2017. Gridded Population of the World, Version 4 (GPWv4): Population Density, Revision 10. Palisades, NY: NASA Socioeconomic Data and Applications Center (SEDAC). https://doi.org/10.7927/H4DZ068D. Accessed 21 Aug 2018.

Resolution: 1km
Year: 2015
Units: persons per sq km

Folder /data contains 3 colored PNG files displaying colors based on different interval classes.
Data is extremely skewed, vast majority of  pixel values are below 100. View ca_popdens_histogram.png or analyze original geotiff for stats. Note histogram is logarithmically transformed.

Actual max Value is ~37700.

popdens_cap1000_0.png - Equal sized intervals, but 1000 is arbitrarily set as the cap and all values >1000 are seen as the darkest color.
popdens_cap5000_1.png - Equal sized intervals, but 5000 is arbitrarily set as the cap all values >5000 are seen as the darkest color.
popdens_geo_2.png - Intervals determined geometrically, where interval classes are inequal sizes but observe equally sized frequencies.

Visually, these are very similar. However the densest areas have different intensities of the color red.